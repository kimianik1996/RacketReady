package com.example.racketready;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import com.example.racketready.DatabaseHelper;


@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class RacketReadyApplication {

	public static void main(String[] args) {
		SpringApplication.run(RacketReadyApplication.class, args);



	}

	@WebServlet("/loginServlet")
	public static class FormProcess extends HttpServlet {

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ArrayList<String> errs = new ArrayList<>();
			String firstName = request.getParameter("firstName"); // Get First Name From Forme
			String lastName = request.getParameter("lastName"); // Get Last Name From Forme
			String fullName = null;
			if (firstName != null && lastName != null) {
				fullName = firstName + " " + lastName;
			}else{
				if (firstName == null){
					errs.add("Please enter a First Name!");
				} else {
					errs.add("Please enter a Last Name!");
				}
			}

			String email = request.getParameter("email"); // Get Email From Forme
			if (email == null) {
				errs.add("Please enter an Email!");
			}

			String username = request.getParameter("username");
			if (username == null) {
				errs.add("Please enter a Username!");
			}

			String password = request.getParameter("password"); // Get First Password From Form
			String confirmPassword = request.getParameter("confirmPassword"); // Get Confirmation Password From Form E

			if (password == null || confirmPassword == null) {
				errs.add("Please enter a Password!");
			}
			if (!password.equals(confirmPassword)) {
				errs.add("Passwords do not match!");
			}

			String dob_year = request.getParameter("date_year"); // DOB Year
			String dob_month = request.getParameter("date_month"); // DOB month
			String dob_day = request.getParameter("date_day"); // DOB Day

			String[] match_type = request.getParameterValues("match_type"); // Match Type array, form data returns collection of checkboxes
			StringWriter matches = new StringWriter();
			if (match_type != null) {
				for (String match : match_type) {
					matches.append(match);
				}
			}
			String preferredMatch = matches.toString();
			if (preferredMatch == null) {
				errs.add("Please enter a Preferred Match!");
			}

			String skillLevel = request.getParameter("skillLevel"); // Skill Level array, returns only 1 radio value
			if (skillLevel == null) {
				errs.add("Please enter a Skill Level!");
			}

			String location = request.getParameter("location"); // Location data
			if (location == null) {
				errs.add("Please enter your Location!");
			}
			String terms = request.getParameter("terms"); // Terms Of Service Check
			if (terms == null) {
				errs.add("Please accept the Terms Of Use!");
			}
			// If errors are empty, append data to database.
			if (errs.isEmpty()){
				try{
					Connection con = DatabaseHelper.getDatabaseConnection();
					PreparedStatement insertData = con.prepareStatement("INSERT INTO RacketReadyDB(full_name,email,username,password_hash,date_of_birth,skill_level,preffered_match,location,profile_picture_url) VALUES (?,?,?,?,?,?,?,?,?)");
					insertData.setString(1, fullName);
					insertData.setString(2, email);
					insertData.setInt(4, password.hashCode());
					//insertData.setString(5, );
					insertData.setString(6, skillLevel);
					insertData.setString(7, preferredMatch);
					insertData.setString(8, location);
					//insertData.setString(9, profilePic);
					insertData.executeUpdate();
					con.close();
					// Success
				}catch (Exception e){
					e.printStackTrace();
				}
			}
			// Else relay back errors
		}
	}

/** 		CREATE TABLE INFORMATION
 * CREATE TABLE users (
 *     user_id INT AUTO_INCREMENT PRIMARY KEY, 0 <<< Index
 *     full_name VARCHAR(100) NOT NULL, 1
 *     email VARCHAR(100) NOT NULL UNIQUE, 2
 *     username VARCHAR(20) NOT NULL UNIQUE, 3
 *     password_hash VARCHAR(255) NOT NULL, 4
 *     date_of_birth DATE NOT NULL, 5
 *     skill_level ENUM('Beginner', 'Intermediate', 'Advanced', 'Professional') NOT NULL, 6
 *     preferred_match SET('Singles', 'Doubles') NOT NULL, 7
 *     location VARCHAR(100) NOT NULL, 8
 *     profile_picture_url VARCHAR(255), 9
 *     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 10
 *     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP 11
 * );
 * Additional Information
 * user_id: An auto-incrementing primary key to uniquely identify each user.
 * full_name: The user's full name, which can be up to 100 characters long.
 * email: The user's email address, which must be unique and up to 100 characters long.
 * password_hash: The hashed password for the user's account to ensure security.
 * skill_level: The user's skill level, which can be one of the specified ENUM values.
 * preferred_match: The user's preferred match type, which can include both singles and doubles.
 * location: The user's location, which can be up to 100 characters long.
 * profile_picture_url: The URL to the user's profile picture, which can be up to 255 characters long.
 * created_at: The timestamp for when the user account was created.
 * updated_at: The timestamp for when the user account was last updated, automatically updated on any change.
 * To Hold the information from the above fields, a database table called users will be created and each input corresponding to a field in the database table . I could go on to design a normalised database tables in the first normal forms but all the data and the ways this web application will work is not yet fully grasped. This table will be normalised as we progress if need be be but for now lets go with a single table. I also considered having a username but I think only an email address should be used to login for simplicity.
 */
}
